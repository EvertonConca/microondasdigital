<!DOCTYPE html>
<html lang="pt_br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Microondas Digital</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap">
    <script src="https://cdn.lordicon.com/lordicon.js"></script>
    
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <div class="container">
        <h1>Microondas Digital</h1>
        <div class="countdown-container">
            <svg class="countdown-svg" viewBox="0 0 100 100">
                <defs>
                    <linearGradient id="warm-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style="stop-color:#85FFBD"></stop>
                        <stop offset="100%" style="stop-color:#FFFB7D"></stop>
                    </linearGradient>
                </defs>
                <circle class="countdown-circle" cx="50" cy="50" r="45"></circle>
            </svg>
            <div class="countdown-text" id="countdown">00:00</div>
        </div>
        <div class="controls">
            <input type="number" id="timeInput" placeholder="Insira o tempo em segundos" min="1">
            <div class="buttons">
                <button id="startBtn"><lord-icon
                    src="https://cdn.lordicon.com/aklfruoc.json"
                    trigger="hover"
                    colors="primary:#ffffff">
                </lord-icon>Iniciar</button>
                <button id="pauseBtn"><lord-icon
                    src="https://cdn.lordicon.com/ptvmrrcc.json"
                    trigger="hover"
                    colors="primary:#ffffff">
                </lord-icon>Pausar</button>
                <button id="resetBtn"><lord-icon
                    src="https://cdn.lordicon.com/rsbokaso.json"
                    trigger="hover"
                    colors="primary:#ffffff">
                </lord-icon>Resetar</button>
            </div>
        </div>
    </div>
    
    <!-- Script JS -->
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
</body>
</html><?php /**PATH /home/everton/Documentos/cursos/TI/larav/microondas_digital/resources/views/home.blade.php ENDPATH**/ ?>